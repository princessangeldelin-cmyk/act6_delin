
  /*
    MIT License
    
    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    */
    
import express from "express";
import { homePage } from "../controllers/homeController.js";
const router = express.Router();
import {teachers as teacherscontroller} from "../controllers/teachersController.js";
import {students as studentscontroller} from "../controllers/studentsController.js";
import {courses as coursescontroller} from "../controllers/coursesController.js";
import {enrollments as enrollmentscontroller} from "../controllers/enrollmentsController.js";
import {classrooms as classroomscontroller} from "../controllers/classroomsController.js";
router.get("/", homePage);

router.post("/students", studentscontroller.insert);
router.get("/students", studentscontroller.selectAll);
router.get("/students/:id", studentscontroller.selectById);

router.post("/teachers", teacherscontroller.insert);
router.get("/teachers", teacherscontroller.selectAll);
router.get("/teachers/:id", teacherscontroller.selectById);

router.post("/courses", coursescontroller.insert);
router.get("/courses", coursescontroller.selectAll);
router.get("/courses/:id", coursescontroller.selectById);

router.post("/enrollments", enrollmentscontroller.insert);
router.get("/enrollments", enrollmentscontroller.selectAll);
router.get("/enrollments/:id", enrollmentscontroller.selectById);

router.post("/classrooms", classroomscontroller.insert);
router.get("/classrooms", classroomscontroller.selectAll);
router.get("/classrooms/:id", classroomscontroller.selectById);

export default router;
